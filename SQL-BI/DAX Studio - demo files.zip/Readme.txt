The "DAX Studio.pbix" file is used in the videos of the DAX Studio section.
Open the "DAX Studio.pbix" file in Power BI Desktop, and then open DAX Studio
from the External Tools ribbon, or open DAX Studio from the Windows Start menu and connect to the PBI Model named "DAX Studio".